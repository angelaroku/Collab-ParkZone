package com.example.parkingzonemadrid.model

data class Favorito(
    // val(solo get) var -> get y set automáticos
    val id_favorito: Int,
    var nombre_favorito: String,
    //elementos que relacionan con otras clases
    // y se agregan al crearse desde la app
    var id_usuario: Int, var  id_direccion:Int

)

//AQUI NO INTERESA el companion object
// el conteo queremos se guarde  solo en la clase que tiene su CRUD