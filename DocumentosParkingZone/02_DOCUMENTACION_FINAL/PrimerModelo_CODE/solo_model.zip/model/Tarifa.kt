package com.example.parkingzonemadrid.model

data class Tarifa(
    // val(solo get) var -> get y set automáticos
    val id_tarifa: Int,
    var color: TipoColor,
    var precio: Float
) {
    //uso de companion object para autogenerar los id's
    // y la cuenta se guarde de manera general en la app,
    //no solo desde la clase que tiene su CRUD
    companion object{
        private var contador = 0

        fun generarId(): Int{
            contador ++
            return contador
        }
    }
}